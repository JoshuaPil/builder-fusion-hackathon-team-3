export type Category =
  | "resorts"
  | "dining"
  | "entertainment"
  | "spas"
  | "nightlife"
  | "pools";

export interface Room {
  id: string;
  adults: number;
  children: number;
}

export function formatDateRange(
  start: Date | null,
  end: Date | null,
): string {
  if (!start) return "";
  const month = (d: Date) => d.toLocaleDateString("en-US", { month: "short" });
  if (!end) return `${month(start)} ${start.getDate()}`;
  if (
    start.getMonth() === end.getMonth() &&
    start.getFullYear() === end.getFullYear()
  ) {
    return `${month(start)} ${start.getDate()}–${end.getDate()}`;
  }
  return `${month(start)} ${start.getDate()} – ${month(end)} ${end.getDate()}`;
}

export function formatGuestSummary(rooms: Room[]): string {
  if (rooms.length === 0) return "";
  const totalAdults = rooms.reduce((s, r) => s + r.adults, 0);
  const totalChildren = rooms.reduce((s, r) => s + r.children, 0);
  if (rooms.length === 1) {
    const parts: string[] = [];
    if (totalAdults > 0)
      parts.push(`${totalAdults} Adult${totalAdults !== 1 ? "s" : ""}`);
    if (totalChildren > 0)
      parts.push(
        `${totalChildren} Child${totalChildren !== 1 ? "ren" : ""}`,
      );
    return parts.join(", ");
  }
  const totalGuests = totalAdults + totalChildren;
  return `${rooms.length} rooms, ${totalGuests} guest${totalGuests !== 1 ? "s" : ""}`;
}

export const CATEGORY_LABELS: Record<Category, string> = {
  resorts: "Resorts",
  dining: "Dining",
  entertainment: "Entertainment",
  spas: "Spas",
  nightlife: "Nightlife",
  pools: "Pools",
};

export const CATEGORY_EMOJI: Record<Category, string> = {
  resorts: "🗝️",
  dining: "🍴",
  entertainment: "🎲",
  spas: "🌸",
  nightlife: "🦞",
  pools: "🏊",
};

export const ALL_CATEGORIES: Category[] = [
  "resorts",
  "dining",
  "entertainment",
  "spas",
  "nightlife",
  "pools",
];
