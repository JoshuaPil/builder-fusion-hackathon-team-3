import { useBookingState } from "@/hooks/useBookingState";
import { BookingLayout } from "@/components/booking/BookingLayout";
import { BookingSearch } from "@/components/booking/BookingSearch";
import { CategoryGrid } from "@/components/booking/CategoryGrid";
import {
  CATEGORY_LABELS,
  CATEGORY_EMOJI,
  formatDateRange,
  formatGuestSummary,
} from "@/lib/booking-utils";

export default function Index() {
  const {
    category,
    setCategory,
    location,
    activeSection,
    toggleSection,
    dateRange,
    rooms,
    clear,
  } = useBookingState();

  const dateValue = formatDateRange(dateRange.start, dateRange.end) || null;
  const guestValue = formatGuestSummary(rooms) || null;
  const hasSelections = !!(category || location || dateRange.start);

  return (
    <BookingLayout activeTab="book">
      {/* Header */}
      <div className="flex items-start justify-between px-5 pt-8 pb-5">
        <h1 className="text-4xl font-bold tracking-tight">Book</h1>
        {category && (
          <div className="flex items-center gap-1.5 bg-gray-100 rounded-full px-3 py-1.5 mt-1">
            <span className="text-base leading-none">{CATEGORY_EMOJI[category]}</span>
            <span className="text-sm font-medium text-gray-800">
              {CATEGORY_LABELS[category]}
            </span>
          </div>
        )}
      </div>

      {/* Category grid */}
      <CategoryGrid selected={category} onSelect={setCategory} />

      {/* Search panel – Location / Dates / Guests */}
      <div className="mt-6">
        <BookingSearch
          location={location}
          dates={dateValue}
          guests={guestValue}
          activeSection={activeSection}
          onSectionPress={toggleSection}
          onClear={clear}
          onAction={() => {}}
          showActions={hasSelections}
        >
          {/* Active section picker – wired up in later screens */}
          {null}
        </BookingSearch>
      </div>
    </BookingLayout>
  );
}
