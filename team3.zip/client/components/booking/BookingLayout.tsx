import { ReactNode } from "react";
import { BottomNav } from "./BottomNav";

interface BookingLayoutProps {
  children: ReactNode;
  activeTab?: "home" | "book" | "discover" | "rewards" | "account";
  onTabChange?: (tab: "home" | "book" | "discover" | "rewards" | "account") => void;
}

export function BookingLayout({ children, activeTab, onTabChange }: BookingLayoutProps) {
  return (
    <div className="flex flex-col h-screen max-w-[390px] mx-auto bg-white overflow-hidden">
      <div className="flex-1 overflow-y-auto">{children}</div>
      <BottomNav activeTab={activeTab} onTabChange={onTabChange} />
    </div>
  );
}
