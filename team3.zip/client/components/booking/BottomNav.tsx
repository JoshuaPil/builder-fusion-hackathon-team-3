import { Home, CalendarDays, Sparkles, Ticket, User } from "lucide-react";
import { cn } from "@/lib/utils";

type Tab = "home" | "book" | "discover" | "rewards" | "account";

const TABS: Array<{ id: Tab; label: string; Icon: typeof Home }> = [
  { id: "home", label: "Home", Icon: Home },
  { id: "book", label: "Book", Icon: CalendarDays },
  { id: "discover", label: "Discover", Icon: Sparkles },
  { id: "rewards", label: "Rewards", Icon: Ticket },
  { id: "account", label: "Account", Icon: User },
];

interface BottomNavProps {
  activeTab?: Tab;
  onTabChange?: (tab: Tab) => void;
}

export function BottomNav({ activeTab = "home", onTabChange }: BottomNavProps) {
  return (
    <nav className="flex items-center justify-around bg-black h-16 px-2 shrink-0">
      {TABS.map(({ id, label, Icon }) => {
        const active = activeTab === id;
        return (
          <button
            key={id}
            onClick={() => onTabChange?.(id)}
            className="flex flex-col items-center gap-0.5 flex-1"
          >
            <Icon
              size={22}
              className={cn(active ? "text-white" : "text-gray-500")}
              strokeWidth={active ? 2 : 1.5}
            />
            <span
              className={cn(
                "text-[10px]",
                active ? "text-white font-semibold" : "text-gray-500",
              )}
            >
              {label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
