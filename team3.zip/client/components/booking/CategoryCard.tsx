import { cn } from "@/lib/utils";
import { Category, CATEGORY_EMOJI, CATEGORY_LABELS } from "@/lib/booking-utils";

interface CategoryCardProps {
  category: Category;
  selected: boolean;
  onSelect: () => void;
}

export function CategoryCard({ category, selected, onSelect }: CategoryCardProps) {
  return (
    <button
      onClick={onSelect}
      className={cn(
        "relative flex flex-col justify-between p-3 rounded-2xl overflow-hidden text-left w-full",
        "min-h-[130px]",
        "bg-gradient-to-br from-neutral-100 via-stone-50 to-neutral-200",
        selected ? "ring-2 ring-black" : "ring-0",
      )}
    >
      <span className="text-[13px] font-medium text-gray-900 leading-tight">
        {CATEGORY_LABELS[category]}
      </span>
      <span
        className="text-5xl self-end leading-none"
        role="img"
        aria-label={CATEGORY_LABELS[category]}
      >
        {CATEGORY_EMOJI[category]}
      </span>
    </button>
  );
}
