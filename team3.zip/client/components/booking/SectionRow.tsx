import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface SectionRowProps {
  label: string;
  value: string | null;
  onPress: () => void;
  expanded?: boolean;
  children?: ReactNode;
}

export function SectionRow({
  label,
  value,
  onPress,
  expanded = false,
  children,
}: SectionRowProps) {
  return (
    <div>
      <button
        onClick={onPress}
        className="w-full flex items-center justify-between px-5 py-4"
      >
        <span
          className={cn(
            "text-base font-medium",
            expanded ? "text-gray-900" : "text-gray-400",
          )}
        >
          {label}
        </span>
        {!expanded && (
          <span
            className={cn(
              "text-sm px-4 py-1.5 rounded-full border",
              value
                ? "border-gray-800 text-gray-900 bg-white font-medium"
                : "border-gray-200 text-gray-500 bg-white",
            )}
          >
            {value ?? "Select"}
          </span>
        )}
      </button>
      {expanded && children && (
        <div className="px-5 pb-4">{children}</div>
      )}
    </div>
  );
}
