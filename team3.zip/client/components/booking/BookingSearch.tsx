import { ReactNode } from "react";
import { SectionRow } from "./SectionRow";
import { cn } from "@/lib/utils";

export type SearchSection = "location" | "dates" | "guests";

interface BookingSearchProps {
  location: string | null;
  dates: string | null;
  guests: string | null;
  activeSection: SearchSection | null;
  onSectionPress: (section: SearchSection) => void;
  onClear: () => void;
  onAction: () => void;
  actionLabel?: string;
  actionEnabled?: boolean;
  showActions?: boolean;
  children?: ReactNode;
}

export function BookingSearch({
  location,
  dates,
  guests,
  activeSection,
  onSectionPress,
  onClear,
  onAction,
  actionLabel = "Search",
  actionEnabled = true,
  showActions = false,
  children,
}: BookingSearchProps) {
  return (
    <div className="bg-white rounded-t-3xl border-t border-gray-100">
      <SectionRow
        label="Location"
        value={location}
        onPress={() => onSectionPress("location")}
        expanded={activeSection === "location"}
      >
        {activeSection === "location" ? children : null}
      </SectionRow>

      <div className="h-px bg-gray-100 mx-5" />

      <SectionRow
        label="Dates"
        value={dates}
        onPress={() => onSectionPress("dates")}
        expanded={activeSection === "dates"}
      >
        {activeSection === "dates" ? children : null}
      </SectionRow>

      <div className="h-px bg-gray-100 mx-5" />

      <SectionRow
        label="Guests"
        value={guests}
        onPress={() => onSectionPress("guests")}
        expanded={activeSection === "guests"}
      >
        {activeSection === "guests" ? children : null}
      </SectionRow>

      {showActions && (
        <div className="flex gap-3 px-5 py-4">
          <button
            onClick={onClear}
            className="flex-1 py-3 rounded-full border border-gray-300 text-sm font-semibold tracking-widest text-gray-800 uppercase"
          >
            Clear
          </button>
          <button
            onClick={onAction}
            disabled={!actionEnabled}
            className={cn(
              "flex-1 py-3 rounded-full text-sm font-semibold tracking-widest uppercase transition-opacity",
              actionEnabled
                ? "bg-black text-white"
                : "bg-gray-200 text-gray-400",
            )}
          >
            {actionLabel}
          </button>
        </div>
      )}
    </div>
  );
}
